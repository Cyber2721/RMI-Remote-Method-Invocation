/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package artops;

import java.rmi.Naming;

/**
 *
 * @author Cyber
 */
public class RMIClient {

    public static void main(String[] args) {
        try {
            double a = 20, b = 5;
            RMIInterface ri = (RMIInterface) Naming.lookup("rmi://localhost:3232/AO");
            double sum = ri.add(a, b);
            double diff = ri.subtract(a, b);
            System.out.println("Sum is " + sum);
            System.out.println("Diff is " + diff);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
