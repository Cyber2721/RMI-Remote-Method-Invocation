/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package artops;

import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;

/**
 *
 * @author Cyber
 */
public class RMIServer extends UnicastRemoteObject implements RMIInterface{
    
    public RMIServer() throws RemoteException{
    }
    public double add(double a, double b ) throws RemoteException {
        return a + b;
    }
        public double subtract(double a, double b ) throws RemoteException {
        return a - b;
    }
        public static void main(String args[]) {
            try {
            Registry r = LocateRegistry.createRegistry(3232);
            RMIServer s = new RMIServer();
            r.rebind("AO", s);
            System.out.println("Server Instantiated!");
            }
            catch(Exception e) {
                e.printStackTrace();
            }
        }
}
